Version: V01R00

Description:

This package contains a complete Missile Air-to-Ground model with its textures, materials, animation and more!

Package also includes:

- 1 Missile 3D model (fbx format) in 3 parts (Guidance, Fuze and Range).
- 1 Missile texture in png format (diffuse, normal and occlusion)
- 1 smoke texture (png format)
- 1 rocket fx sound
- 1 animation for Missile wings deployment
- 4 prefabs
- 1 DEMO scene.



When you use our asset on projet, share with us you creation in the asset store comments :)

	
Lunar Cats Studio
E-mail: lunar.cats.studio@gmail.com
Facebook: http://lunarcatsstudio.com